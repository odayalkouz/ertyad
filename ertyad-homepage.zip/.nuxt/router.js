import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _210b23af = () => interopDefault(import('..\\pages\\aboutus.vue' /* webpackChunkName: "pages/aboutus" */))
const _0fbe650e = () => interopDefault(import('..\\pages\\blog.vue' /* webpackChunkName: "pages/blog" */))
const _80b9a814 = () => interopDefault(import('..\\pages\\case-studies.vue' /* webpackChunkName: "pages/case-studies" */))
const _35e99957 = () => interopDefault(import('..\\pages\\contact-us.vue' /* webpackChunkName: "pages/contact-us" */))
const _ff590dd4 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))
const _8105a03a = () => interopDefault(import('..\\pages\\news\\index.vue' /* webpackChunkName: "pages/news/index" */))
const _e2023622 = () => interopDefault(import('..\\pages\\whitepaper.vue' /* webpackChunkName: "pages/whitepaper" */))
const _1e9c9317 = () => interopDefault(import('..\\pages\\news\\_id\\index.vue' /* webpackChunkName: "pages/news/_id/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/aboutus",
    component: _210b23af,
    name: "aboutus___ar"
  }, {
    path: "/blog",
    component: _0fbe650e,
    name: "blog___ar"
  }, {
    path: "/case-studies",
    component: _80b9a814,
    name: "case-studies___ar"
  }, {
    path: "/contact-us",
    component: _35e99957,
    name: "contact-us___ar"
  }, {
    path: "/en",
    component: _ff590dd4,
    name: "index___en"
  }, {
    path: "/news",
    component: _8105a03a,
    name: "news___ar"
  }, {
    path: "/whitepaper",
    component: _e2023622,
    name: "whitepaper___ar"
  }, {
    path: "/en/aboutus",
    component: _210b23af,
    name: "aboutus___en"
  }, {
    path: "/en/blog",
    component: _0fbe650e,
    name: "blog___en"
  }, {
    path: "/en/case-studies",
    component: _80b9a814,
    name: "case-studies___en"
  }, {
    path: "/en/contact-us",
    component: _35e99957,
    name: "contact-us___en"
  }, {
    path: "/en/news",
    component: _8105a03a,
    name: "news___en"
  }, {
    path: "/en/whitepaper",
    component: _e2023622,
    name: "whitepaper___en"
  }, {
    path: "/en/news/:id",
    component: _1e9c9317,
    name: "news-id___en"
  }, {
    path: "/news/:id",
    component: _1e9c9317,
    name: "news-id___ar"
  }, {
    path: "/",
    component: _ff590dd4,
    name: "index___ar"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
