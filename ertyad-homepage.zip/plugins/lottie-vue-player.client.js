import Vue from 'vue'
import LottieVuePlayer from '@lottiefiles/vue-lottie-player'
Vue.use(LottieVuePlayer)
