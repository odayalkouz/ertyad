<template lang="pug">
  main.case-studies
    app-section
      template(#heading)
        h1.heading--lg {{ $t('nav.caseStudies') }}
      ul.case-studies__list
        li.case-study(
          v-for="caseStudy of caseStudies"
          :key="caseStudy.id"
        )
          file-card(
            :heading="`${$t(caseStudy.heading)}`"
            :description="`${$t(caseStudy.description)}`"
            :image-url="`${caseStudy.imageUrl}?random=${caseStudy.id}`"
            :file-url="caseStudy.fileUrl"
          )

</template>


<script>
import { caseStudies } from '@/content/case-studies.content'
import AppSection from '../components/app/section.vue'
import FileCard from '../components/cards/FileCard'

export default {
  name: 'CaseStudiesPage',

  components: {
    AppSection,
    FileCard
  },

  data () {
    return {
      caseStudies
    }
  }
}
</script>


<style lang="sass" scoped >
.case-studies
  &__list
    padding: 0
    display: grid
    gap: 2rem
    grid-template-columns: repeat(4, 1fr)

    @media only screen and (max-width: $lg)
      grid-template-columns: repeat(3, 1fr)
      gap: 1.5rem

    @media only screen and (max-width: $md)
      grid-template-columns: repeat(2, 1fr)
      gap: 1rem

    @media only screen and (max-width: $sm)
      grid-template-columns: repeat(1, 1fr)
</style>

