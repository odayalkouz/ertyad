<template lang="pug">
  .AboutUsPage
    app-section#about.about(
      :wideContent="true"
    )
      template(#heading)
        h2.heading--lg.mb-8
          | {{ $t('aboutusPage.title') }}
      template
        AboutAbout
    app-section.our-managment.secondary#our-managment
      template(#heading)
        h2.heading--lg.text-center.mb-8
          | {{ $t('ourManagment.heading') }}
      template
        Managment
    app-section.our-trainees.primary#our-trainees
      template(#heading)
        h2.heading--lg.text-center.mb-8
          | {{ $t('ourTrainees.heading') }}
      template
        Trainees
</template>
<script>
import AppSection from '../components/app/section'
import AboutAbout from '../components/about/about'
import Managment from '../components/about/managment'
import Trainees from '../components/about/trainee'
export default {
  name: 'AboutUsPage',
  components: { Trainees, Managment, AboutAbout, AppSection },
  data () {
    return {
    }
  }
}
</script>
<style lang="sass" scoped>

</style>
