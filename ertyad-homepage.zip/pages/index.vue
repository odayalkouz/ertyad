<template lang="pug">
  .homepage
    bannerSlider
    app-section.partners#partners.d-flex.flex-row
      template(#heading)
        v-row(no-gutters='')
          v-col.d-flex.align-center(cols='12' sm='3')
            h2.heading--lg.text-center
              | {{ $t('ourPartners.heading') }}
          v-col(cols='12' sm='9')
            slider.d-flex.flex-row(
              :items="partnersList"
              :numberOfSliders="4"
            )
    app-section#support.support(
      content-width="wide"
    )
      template(#heading)
        h2.heading--lg.text-center.mb-8
          | {{ $t('support.heading') }}
      template
        services.mt-6(
          :items="cardsItems"
        )
    app-section.aboutUs(
      content-width="wide"
    )
      template
        About.mt-6
    app-section#achievements.achievements(
      content-width="wide"
    )
      template(#heading)
        h2.heading--lg.text-center.mb-8
          | {{ $t('Achievements.heading') }}
      template
        achievements.mt-6
    app-section.our-clients#our-clients
      template(#heading)
        h2.heading--lg.text-center
          | {{ $t('ourClients.heading') }}
      template
        slider(
          :items="clientsList"
          :numberOfSliders="4"
        )
    app-section.what-client-say(
      content-width="wide"
    )
      template(#heading)
        h2.heading--lg.text-center.mb-8
          | {{ $t('WhatClientSay.heading') }}
      template
        WhatClientSay.mt-6
        VideoPopup.mt-5
    app-section.BrowseOurPrograms(
      content-width="wide"
    )
      template(#heading)
        h2.heading--lg.text-center.mb-8
          | {{ $t('BrowseOurPrograms.heading') }}
      template
        BrowseOurPrograms.TabsContents.mt-6
</template>
<script>
import { partners, clients, support } from '@/media.config'
import Services from '@/components/services'
import BannerSlider from '@/components/bannerSlider'
import AppSection from '../components/app/section'
import Slider from '../components/slider'
import About from '../components/about'
import Achievements from '../components/achievements'
import WhatClientSay from '../components/whatclientsay'
import BrowseOurPrograms from '../components/browseourprograms'
import VideoPopup from '../components/videopopup'
export default {
  name: 'Homepage',
  components: { VideoPopup, BrowseOurPrograms, WhatClientSay, Achievements, About, Services, AppSection, BannerSlider, Slider },
  data () {
    return {
      numbers: 10
    }
  },
  computed: {
    partnersList () {
      return partners.images
    },
    clientsList () {
      return clients.images
    },
    cardsItems () {
      return this.$t('support.list').map((item, i) => {
        return {
          fileUrl: support.images[i],
          ...item
        }
      })
    }
  }
}
</script>
<style lang="sass">
.main-container-hover
  position: relative
  .v-image
    position: absolute
</style>
