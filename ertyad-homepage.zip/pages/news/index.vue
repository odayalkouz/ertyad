<template lang="pug">
  app-section.News.primary#News
    template
      h2.heading--lg.mb-8
        | {{ $t('News.heading') }}
    template
    .swiper-container
      .swiper-wrapper
        .swiper-slide(
          v-for="new1 in news"
          :key="new1.id"
        )
          v-card.mx-auto(max-width='344').pb-5
            nuxt-link( :to="'news/'+new1.id")
              v-img(
                :aspect-ratio='16/9'
                :src="new1.imageSrc || defaultImage"
                :alt="new1.alt || new1.name"
                height='200px')
            v-card-title(
              v-html="new1.name"
              :title="new1.name"
            )
            v-card-subtitle.d-none(
              v-html="new1.show"
            )
            v-card-actions.d-none
              nuxt-link( :to="'news/'+new1.id")
                v-btn(color='#11bcce' text='')
                  | {{ $t('News.more') }}
              v-spacer
              v-btn(icon='' @click='ToggleMore(new1)')
                v-icon(
                v-html="new1.show ? 'mdi-chevron-up' : 'mdi-chevron-down'"
                )
            v-expand-transition
              div(v-show="new1.show" :class="{'d-none' : !new1.show}")
                v-divider
                v-card-text.pb-0(
                  v-html="new1.paragraph"
                )
      .swiper-pagination
      .swiper-button-prev
      .swiper-button-next
</template>

<script>
import { News } from '@/media.config'
// eslint-disable-next-line import/no-named-as-default
import Swiper, { Navigation, Pagination } from 'swiper'
import 'swiper/swiper-bundle.css'
import AppSection from '@/components/app/section'
Swiper.use([Navigation, Pagination])
export default {
  name: 'NewsPage',
  components: { AppSection },
  data () {
    return {
      swiper: null,
      defaultImage: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/avatars/avatar.png'
    }
  },
  computed: {
    news () {
      const newsMedia = News.images
      return newsMedia.map((image, i) => {
        return {
          ...image,
          id: this.$t(`News.list[${i}].id`),
          name: this.$t(`News.list[${i}].name`),
          paragraph: this.$t(`News.list[${i}].paragraph`)
        }
      })
    }
  },
  mounted () {
    const breakpoints = {}

    breakpoints[this.$vuetify.breakpoint.thresholds.sm] = {
      slidesPerView: 3,
      slidesPerGroup: 3
    }
    breakpoints[this.$vuetify.breakpoint.thresholds.xs] = {
      slidesPerView: 2,
      slidesPerGroup: 2
    }
    this.swiper = new Swiper('.News .swiper-container', {
      slidesPerView: 1,
      slidesPerGroup: 1,
      breakpoints,
      spaceBetween: 30,
      pagination: {
        el: '.News .swiper-pagination',
        clickable: true
      },
      navigation: {
        nextEl: '.News .swiper-button-next',
        prevEl: '.News .swiper-button-prev'
      }
    })
  },
  methods: {
    ToggleMore (new1) {
      new1.show = !new1.show
    }
  }
}
</script>
<style lang="sass" scoped>
.paragraph
  color: #80969e !important
  font-size: 0.9em
  line-height: 1.8
  overflow: hidden
  display: -webkit-box
  -webkit-line-clamp: 5
  -webkit-box-orient: vertical
.v-card
  border: solid 1px #d9d9d9
.v-application--is-rtl
  .paragraph
    text-align: right
.v-application--is-ltr
  .paragraph
    text-align: left
.v-card__title
  font-size: 0.9rem
  overflow: hidden
  display: -webkit-box
  -webkit-line-clamp: 2
  -webkit-box-orient: vertical
  min-height: 64px
.v-card__text
  width: 90%
  overflow: hidden
  display: -webkit-box
  -webkit-line-clamp: 3
  -webkit-box-orient: vertical
  line-height: 43.2px
  font-size: 0.8rem
.swiper-pagination-bullets
  bottom: 0 !important
.oday
  display: none
</style>


