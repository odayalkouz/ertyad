<template lang="pug">
  app-section.News.primary#News
    template
      h2.heading--lg.mb-8
        | {{ $t('News.heading') }}
    template
      v-row(justify="space-around")
        v-col(cols="12" xl="12" lg="12" md="12" sm="12" xs="12")
          h2.heading--md.mt-6
            | {{ news(ids).name }}
          v-img(:src='newsImage(ids).imageSrc' aspect-ratio='1' contain  position="top")
        v-col(cols="12" xl="12" lg="12" md="12" sm="12" xs="12")
          p.paragraph(v-html="news(ids).paragraph")
</template>

<script>
// eslint-disable-next-line import/no-named-as-default
import { News } from '@/media.config'
import AppSection from '@/components/app/section'
export default {
  name: 'NewsPage',
  components: { AppSection },
  data () {
    return {
      swiper: null,
      defaultImage: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/avatars/avatar.png',
      ids: this.$route.params.id
    }
  },
  methods: {
    news (id) {
      return this.$t(`News.list[${id}]`)
    },
    newsImage (id) {
      return News.images[id]
    }
  }
}
</script>
<style lang="sass" scoped>
.paragraph
  color: #80969e !important
  font-size: 0.9em
  line-height: 1.8
  overflow: hidden
  display: -webkit-box
  -webkit-line-clamp: 5
  -webkit-box-orient: vertical
//min-height: 113px
.v-card
  border: solid 1px #d9d9d9

.v-application--is-rtl
  .paragraph
    text-align: right

.v-application--is-ltr
  .paragraph
    text-align: left

</style>


