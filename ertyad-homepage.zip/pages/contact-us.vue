<template lang="pug">
  main.contact-us
    app-section(
      container-width="slim"
    )
      template(#heading)
        h1.heading--lg {{ $t('navFooter.contactUs') }}
        contact-us-form

</template>
<script>
import AppSection from '../components/app/section.vue'
import ContactUsForm from '../components/forms/ContactUs.vue'

export default {
  name: 'ContactUsPage',
  components: {
    AppSection,
    ContactUsForm
  }
}
</script>


