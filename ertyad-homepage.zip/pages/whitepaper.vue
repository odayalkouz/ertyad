<template lang="pug">
  .BlogPage
    app-section#white-paper.white-paper(
      :wideContent="true"
    )
      template(#heading)
        h2.heading--lg.mb-8
          | {{ $t('WhitePaperPage.title') }}
      template
        v-simple-table
          template(v-slot:default='')
            thead
              tr
                th
                 h2
                  | {{ $t('WhitePaperPage.title') }}
                th
                 h2
                  | {{ $t('WhitePaperPage.action') }}
            tbody
              tr(v-for='paper in whitePapers' :key='paper.name')
                td {{ paper.name }}
                td
                 a(:href="paper.src" target="_blank")
                    v-icon( color="#11bcce")
                      | mdi-download
</template>
<script>
import { whitepaper } from '@/media.config'
import AppSection from '../components/app/section'
export default {
  name: 'WhitePaperPage',
  components: { AppSection },
  data () {
    return {
    }
  },
  computed: {
    whitePapers () {
      const membersMedia = whitepaper.files
      return membersMedia.map((file, i) => {
        return {
          ...file,
          name: this.$t(`WhitePaperPage.list[${i}].name`)
        }
      }
      )
    }
  }
}
</script>
<style lang="sass" scoped>
.paragraph
  line-height: 2rem
</style>
