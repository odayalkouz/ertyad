<template lang="pug">
  .BlogPage
    app-section#about.about(
      :wideContent="true"
    )
      template
        v-row(justify="space-around")
          v-col(cols="12" xl="12" lg="12" md="12" sm="12" xs="12")
            v-img(:src='blogImage' aspect-ratio='1' max-height="400" position="top" )
              div.fill-height
                div.container.ct-container-header.fill-height.mt-16.mx-8
                  h2.heading--lg.mt-16.white--text
                   | {{ $t('blogPage.title') }}
          v-col(cols="12" xl="12" lg="12" md="12" sm="12" xs="12")
            p.paragraph(v-html="$t('blogPage.paragraph1')")
            h4.heading--lg.mt-16
              | {{ $t('blogPage.subtitle1') }}
            p.paragraph(v-html="$t('blogPage.subparagraph')")
            h4.heading--lg.mt-16
              | {{ $t('blogPage.subtitle2') }}
            p.paragraph(v-html="$t('blogPage.paragraph2')")
            p.paragraph(v-html="$t('blogPage.list1')")
            h4.heading--lg.mt-16
              | {{ $t('blogPage.subtitle3') }}
            p.paragraph(v-html="$t('blogPage.paragraph3')")
            p.paragraph(v-html="$t('blogPage.list2')")
</template>
<script>
import cfg from '@/project.config'
import AppSection from '../components/app/section'
export default {
  name: 'BlogPage',
  components: { AppSection },
  data () {
    return {
      blogImage: cfg.blog.src
    }
  }
}
</script>
<style lang="sass" scoped>
.paragraph
  line-height: 2rem
.theme--light.v-image
  border-radius: 10px
.fill-height
  height: 100%
.container.fill-height
  align-items: center
  display: flex
  flex-wrap: wrap
</style>
