<template lang="pug">
  v-app
    v-main
      app-header
      nuxt
      app-footer
</template>

<script>
import { localeMixin } from '@/lib/mixins'
import AppHeader from '@/components/app/header'
import AppFooter from '@/components/app/footer'

export default {
  components: {
    AppFooter,
    AppHeader
  },
  mixins: [localeMixin]
}
</script>
