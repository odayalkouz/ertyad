module.exports = {
  locale: {
    default: 'ar',
    fallback: 'ar',
    list: [
      { code: 'en', iso: 'en-US', file: '/en/index.js', dir: 'ltr' },
      { code: 'ar', iso: 'ar-EG', file: '/ar/index.js', dir: 'rtl' }
    ]
  },
  themes: {
    light: {
      primary: '#000',
      accent: '#11bcce',
      secondary: '#F5F5F5'
    }
  },
  loginLinks: {
    link1: 'https://training.ertyad.com/ar/login',
    link2: 'https://training.ertyad.com/ar/login'
  },
  logo: {
    logoColor: 'https://daymzie342s7t.cloudfront.net/s/img/ertya/logo.png',
    logoWhite: 'https://daymzie342s7t.cloudfront.net/s/img/ertya/logowhite.png'
  },
  contact: {
    phone: '+966 11-215-1100'
  },
  video: {
    ErtyadTrainee: 'https://www.youtube.com/embed/W3uHu6N4Tp4',
    type: ''
  },
  aboutImage: {
    src: 'https://daymzie342s7t.cloudfront.net/s/img/ertya/aboutus/about.jpg'
  },
  blog: {
    src: 'https://daymzie342s7t.cloudfront.net/s/img/ertya/bannerSlider/4.jpg'
  },
  media: {
    linkedin: 'https://www.linkedin.com/company/ertyadco/',
    twitter: 'https://twitter.com/Ertyadco',
    Youtube: 'https://www.youtube.com/user/ErtyadHypo',
    instagram: 'https://www.instagram.com/ertyad_training/'
  },
  metaContent: {
    ertyad: 'ارتياد',
    text: 'رحلة تطوير المواهب',
    url: 'https://training.ertyad.com',
    keywords: 'خبرة عريقة في فهم التحديات المحلية وتقديم أفضل الممارسات العالمية بالشراكة مع كبرى الجهات التدريبية العالمية في مجال الاستشارات والتدريب والتطوير.' + '\n' + 'منذ عام 2007 تعمل ارتياد على تقديم أفضل الحلول للقادة والكفاءات البشرية التي تعدّ حجر الأساس في نهضة المؤسسات الحكومية والخاصة من خلال تمكينهم وتطويرهم بأرقى الأدوات والمناهج؛ وذلك كجزء أساسي لا يتجزأ من عملية التحوّل العظيمة في أي منظمة.'
  }
}
