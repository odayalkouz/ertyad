<template lang="pug">

  .swiper-container
    .swiper-wrapper
      .swiper-slide(
        v-for="(trainee, i) in trainees"
        :key="i"
      )
        v-card.card.rounded-lg.py-5.px-5.mb-14.text-center.d-flex.flex-column(
          elevation="0"
        )
          v-avatar.mx-auto(
           size="100%"
           tile
          )
            v-img(
              :src="trainee.imageSrc || defaultImage"
              :alt="trainee.alt || trainee.name"
            )
          v-card-title.pa-0
            h3.heading--md.mt-6.mb-4(
              v-html="trainee.name"
            )
          v-card-text.px-0.pb-0( v-if="trainee.paragraph" )
            p.paragraph.color-inherit.font-weight-normal.mb-0(:title="trainee.paragraph")
              | {{ trainee.paragraph }}

    .swiper-pagination

    .swiper-button-prev
    .swiper-button-next
</template>

<script>

import { ourTrainees } from '@/media.config'
// eslint-disable-next-line import/no-named-as-default
import Swiper, { Navigation, Pagination } from 'swiper'
import 'swiper/swiper-bundle.css'

Swiper.use([Navigation, Pagination])

export default {
  name: 'Trainees',
  data () {
    return {
      swiper: null,
      defaultImage: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/avatars/avatar.png'
    }
  },
  computed: {
    trainees () {
      const membersMedia = ourTrainees.images
      return membersMedia.map((image, i) => {
        return {
          ...image,
          name: this.$t(`ourTrainees.list[${i}].name`),
          paragraph: this.$t(`ourTrainees.list[${i}].paragraph`)
        }
      }
      )
    }
  },
  mounted () {
    const breakpoints = {}

    breakpoints[this.$vuetify.breakpoint.thresholds.sm] = {
      slidesPerView: 4,
      slidesPerGroup: 4
    }
    breakpoints[this.$vuetify.breakpoint.thresholds.xs] = {
      slidesPerView: 2,
      slidesPerGroup: 2
    }
    this.swiper = new Swiper('.our-trainees .swiper-container', {
      slidesPerView: 1,
      slidesPerGroup: 1,
      breakpoints,
      spaceBetween: 30,
      pagination: {
        el: '.our-trainees .swiper-pagination',
        clickable: true
      },
      navigation: {
        nextEl: '.our-trainees .swiper-button-next',
        prevEl: '.our-trainees .swiper-button-prev'
      }
    })
  }
}
</script>
<style lang="sass" scoped>
.paragraph
  color: #80969e !important
  font-size: 0.9em
  line-height: 1.8
  overflow: hidden
  display: -webkit-box
  -webkit-line-clamp: 5
  -webkit-box-orient: vertical
  //min-height: 113px
.v-card
  border: solid 1px #d9d9d9
.v-application--is-rtl
  .paragraph
    text-align: right
.v-application--is-ltr
  .paragraph
    text-align: left
</style>


