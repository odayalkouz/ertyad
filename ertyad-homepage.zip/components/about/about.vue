<template lang="pug">
  v-row(justify="space-around")
    v-col(cols="12" xl="7" lg="7" md="12" sm="12" xs="12")
      p.paragraph(v-html="$t('aboutusPage.paragraph')")
    v-col.rounded-lg(cols="12" xl="5" lg="5" md="12" sm="12" xs="12")
      v-img.rounded-lg(:src='aboutImage' aspect-ratio='1.7' rounded)
</template>
<script>
import cfg from '@/project.config'
export default {
  name: 'AppLogo',
  data () {
    return {
      aboutImage: cfg.aboutImage.src
    }
  }
}
</script>
<style lang="sass" scoped>
.paragraph
  line-height: 2em
</style>
