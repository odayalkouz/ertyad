<template lang="pug">

  .swiper-container
    .swiper-wrapper
      .swiper-slide(
        v-for="(manage, i) in managment"
        :key="i"
      )
        v-card.card.rounded-lg.py-10.px-8.mb-14.text-center.d-flex.flex-column(
          elevation="0"
        )
          v-avatar.mx-auto(
           size="130"
          )
            v-img(
              :src="manage.imageSrc || defaultImage"
              :alt="manage.alt || manage.name"
            )
          v-card-title.pa-0
            h3.heading--md.mx-auto.mt-6.mb-4(
              v-html="manage.name"
            )
          v-card-text.px-0.pb-0
            p.paragraph.color-inherit.font-weight-normal.mb-0
              | {{ manage.caption }}

    .swiper-pagination

    .swiper-button-prev
    .swiper-button-next
</template>
<script>
import { ourManagment } from '@/media.config'
// eslint-disable-next-line import/no-named-as-default
import Swiper, { Navigation, Pagination } from 'swiper'
import 'swiper/swiper-bundle.css'
Swiper.use([Navigation, Pagination])
export default {
  name: 'Managment',
  data () {
    return {
      swiper: null,
      defaultImage: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/avatars/avatar.png'
    }
  },
  computed: {
    managment () {
      const membersMedia = ourManagment.images
      return membersMedia.map((image, i) => {
        return {
          ...image,
          name: this.$t(`ourManagment.list[${i}].name`),
          caption: this.$t(`ourManagment.list[${i}].caption`)
        }
      }
      )
    }
  },
  mounted () {
    const breakpoints = {}

    breakpoints[this.$vuetify.breakpoint.thresholds.sm] = {
      slidesPerView: 3,
      slidesPerGroup: 3
    }
    breakpoints[this.$vuetify.breakpoint.thresholds.xs] = {
      slidesPerView: 2,
      slidesPerGroup: 2
    }
    this.swiper = new Swiper('.our-managment .swiper-container', {
      slidesPerView: 1,
      slidesPerGroup: 1,
      breakpoints,
      spaceBetween: 30,
      pagination: {
        el: '.our-managment .swiper-pagination',
        clickable: true
      },
      navigation: {
        nextEl: '.our-managment .swiper-button-next',
        prevEl: '.our-managment .swiper-button-prev'
      }
    })
  }
}
</script>
<style lang="sass" scoped>
.paragraph
  color: #80969e !important
  font-size: 0.9em
  line-height: 1.8
</style>


