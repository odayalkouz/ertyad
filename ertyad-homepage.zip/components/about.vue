<template lang="pug">
  section.about-us.section
    v-container.container--grid
      div.right-content
        h1.mb-3( v-html="$t('aboutUs.title')"
          )
        h2.mb-6( v-html="$t('aboutUs.subtitle')"
        )
        p.paragraph.mb-6( v-html="$t('aboutUs.paragraph')"
        )
        h3.mb-md-0( v-html="$t('aboutUs.BoldText')"
        )
      ul.about-us__list
        li.about.m-auto(
          v-for="(item, i) in items"
          :key="i"
        )
          p.paragraph.about__number.mb-0.text-center(
            v-html="$t(item.number)"
          )
          p.about__title.mb-0.m-auto.text-center.heading--md(
            v-html="$t(item.heading)"
          )
</template>
<script>
import { aboutUs } from '@/media.config'

export default {
  name: 'AboutHomePage',
  computed: {
    items () {
      return this.$t('aboutUs.list').map((item, i) => {
        return { ...item, src: aboutUs.src[i] }
      })
    }
  }
}
</script>
<style lang="sass" scoped>
 .container--grid
  display: grid
  grid-gap: 8.75rem
  gap: 8.75rem
  grid-template-columns: 17.5rem 1fr
  grid-template-rows: auto
  @media only screen and (max-width: $sm)
    grid-template-columns: 1fr !important
    gap: 3.75rem
  .right-content
    h1
      font-size: 1.3rem
      font-weight: 800
    h2
      font-size: 0.9rem
      color: $accent
      font-weight: 500
    h3
      font-size: 0.9rem
      font-weight: 800
    p
      font-size: 0.9rem
      line-height: 1.8rem
  .about-us
    &__list
      margin: 0
      padding: 0
      list-style: none
      display: grid
      gap: 1rem
      grid-template-columns: 1fr
      box-shadow: 0 2px 34px 0 rgba(65, 79, 85, 0.11)
      border-radius: 10px
      overflow: hidden
      @media only screen and (min-width: $xs)
        gap: 0
        grid-template-columns: repeat(3, 1fr)
      @media only screen and (max-width: $sm)
        gap: 0
        grid-template-columns: repeat(1, 1fr)
  .about
    background-color: #FFF
    @media only screen and (min-width: $xs)
      padding: 3rem 1.5rem 1.5rem 1.5rem
    @media only screen and (max-width: $sm)
      padding: 1.5rem 1.5rem 1.5rem 1.5rem
    &__icon
      height: 4.5rem
      width: 4rem
      margin-bottom: 1.5rem
      @media only screen and (min-width: $xs)
        height: 6.25rem
        width: 5rem
        margin: auto
    &__number
      color: $accent
      font-size: 2.2rem

</style>
