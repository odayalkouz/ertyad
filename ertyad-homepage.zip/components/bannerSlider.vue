<template lang="pug">
  v-carousel(:cycle='true' hide-delimiters show-arrows-on-hover height="700" )
    v-carousel-item(v-for='(item,i) in items', :key='i', :src='item.src' top)
      v-container(fill-height)
        v-row.white--text.mx-auto
          v-col.white--text.customize-margin
            h1.animated.fadeInUp.heading--xl(v-html="item.heading")
            br
            a(:href="item.btnSrc" :class="item.visible")
              v-btn(class="animated fadeInUp delay-1s"
                depressed
                color="accent"
                ) {{ item.text }}
</template>
<script>
import { bannerContent } from '@/media.config'
export default {
  name: 'BannerSlider',
  data () {
    return {
      swipe: true
    }
  },
  computed: {
    items () {
      return this.$t('bannerText.list').map((item, i) => {
        return { ...item, src: bannerContent.src[i], btnSrc: bannerContent.btnSrc[i] }
      })
    }
  }
}
</script>
<style lang="sass" scoped>
.customize-margin a
  text-decoration: none
.animated
  -webkit-animation-duration: 2s
  animation-duration: 2s
  -webkit-animation-fill-mode: both
  animation-fill-mode: both
  &.delay-1s
    -webkit-animation-delay: 1s
    animation-delay: 1s
@keyframes fadeInUp
  from
    opacity: 0
    transform: translate3d(0, 100%, 0)
  to
    opacity: 1
    transform: none
.fadeInUp
  -webkit-animation-name: fadeInUp
  animation-name: fadeInUp
</style>
