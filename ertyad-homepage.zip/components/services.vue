<template lang="pug">
  .services-wrp(
    :class="{ 'swiper-container' : isSliderInitialized }"
  )
    v-row.services.justify-lg-center.mx-0.mx-md-n5.mx-lg-n7.px-0(
      tag="ul"
      :class="{ 'swiper-wrapper' : isSliderInitialized }"
    )
      v-col.d-flex.px-0(
        :cols="12"
        :md="6"
        :lg="4"
        v-for="(item, i) in items"
        :key="i"
        tag="li"
        ref="services"
        :class="{ 'swiper-slide' : isSliderInitialized }"
      )
        v-card.card.py-10.px-8.d-flex.flex-column.align-start(
          color="secondary"
        )
          lottie-player.mx-auto(
            :src="item.fileUrl"
            color="transparent"
            speed="1"
            style="width: 95px; height: 95px"
            :class="'item_'+i"
            loop
            autoplay
          )
          v-card-title.pa-0.mx-auto.mt-10
            h3.heading--md.mt-0.mb-6(
              v-html="item.heading"
            )
          v-card-text.px-0.pb-0.mx-auto
            p.paragraph.font-weight-normal.mb-0.text-justify.mx-auto
              | {{ item.text }}
    .swiper-pagination(
      v-show="isSliderInitialized"
    )
</template>
<script>
// eslint-disable-next-line import/no-named-as-default
import Swiper, { Pagination } from 'swiper'
import 'swiper/swiper-bundle.css'
Swiper.use([Pagination])
export default {
  name: 'Services',
  props: {
    items: {
      type: Array,
      required: true
    }
  },
  data () {
    return {
      swiper: null
    }
  },
  computed: {
    isSliderInitialized () {
      if (this.$vuetify.breakpoint.mdAndDown) {
        return true
      }
      if (this.$refs.services) { this.$refs.services.forEach((li) => { li.removeAttribute('style') }) }
      return false
    }
  },
  mounted () {
    const breakpoints = {}
    breakpoints[this.$vuetify.breakpoint.thresholds.sm] = {
      slidesPerView: 2,
      slidesPerGroup: 2,
      spaceBetween: 20
    }
    this.swiper = new Swiper('.services-wrp.swiper-container', {
      slidesPerView: 1,
      slidesPerGroup: 1,
      breakpoints,
      spaceBetween: 40,
      pagination: {
        el: '.services-wrp .swiper-pagination',
        clickable: true
      }
    })
    this.manageSwiper()
    window.addEventListener('resize', this.manageSwiper)
  },
  methods: {
    manageSwiper () {
      this.$nextTick(() => {
        if (!this.isSliderInitialized) {
          this.swiper.disable()
        } else {
          this.swiper.enable()
        }
      })
    }
  }
}
</script>
<style lang="sass" scoped>
.services
  &.swiper-container
    overflow: visible !important
  .swiper-pagination-bullets
    bottom: -1.5rem !important
.services
  flex-wrap: nowrap !important
.card
  color: $background !important
  .v-card__title
    word-break: break-word
  .v-card__text
    color: inherit !important
.v-sheet.v-card
  border-radius: 0 !important
  box-shadow: none
  transition: all 0.5s
  width: 100%
  &:hover
    box-shadow: 0 2px 34px 0 rgba(65, 79, 85, 0.11) !important
    background: #FFF !important
.paragraph
  max-width: 26ch
  line-height: 2.2em
.item_2
  width: 115px !important
  height: 115px !important
</style>
