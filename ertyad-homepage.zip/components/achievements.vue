<template lang="pug">

  .swiper-container
    .swiper-wrapper
      .swiper-slide(
        v-for="(achievement, i) in achievements"
        :key="i"
      )
        v-card.card.pb-5.mb-14.d-flex.flex-column(
          elevation="0"
        )
          v-img.banner-item-image( height="200px"
            :src="achievement.imageSrc || defaultImage"
            :alt="achievement.alt || achievement.name"
          )
            div.white-absolute-container
              v-img(
                aspect-ratio="1"
                contain
                :src="achievement.logo || defaultImage"
                :alt="achievement.alt || achievement.name"
              )
          div.buttom-content.px-6.mt-6
            .text-subtitle-1.mt-4.mb-4(
              v-html="achievement.name"
            )
            v-card-text.paragraph.px-0.pb-0
              p.paragraph.color-inherit.font-weight-normal.mb-0( :title="achievement.paragraph" )
                | {{ achievement.paragraph }}

    .swiper-pagination
    .swiper-button-prev
    .swiper-button-next
</template>

<script>

import { achievements } from '@/media.config'
// eslint-disable-next-line import/no-named-as-default
import Swiper, { Navigation, Pagination } from 'swiper'
import 'swiper/swiper-bundle.css'


Swiper.use([Navigation, Pagination])

export default {
  name: 'Achievements',

  data () {
    return {
      swiper: null,
      defaultImage: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/avatars/avatar.png'
    }
  },
  computed: {
    achievements () {
      const achievementsMedia = achievements.images
      return achievementsMedia.map((image, i) => {
        return {
          ...image,
          name: this.$t(`Achievements.list[${i}].name`),
          paragraph: this.$t(`Achievements.list[${i}].paragraph`)
        }
      }
      )
    }
  },

  mounted () {
    const breakpoints = {}

    breakpoints[this.$vuetify.breakpoint.thresholds.sm] = {
      slidesPerView: 3,
      slidesPerGroup: 3
    }
    breakpoints[this.$vuetify.breakpoint.thresholds.xs] = {
      slidesPerView: 2,
      slidesPerGroup: 2
    }

    this.swiper = new Swiper('.achievements .swiper-container', {
      slidesPerView: 1,
      slidesPerGroup: 1,
      breakpoints,
      spaceBetween: 30,
      observer: true,
      pagination: {
        el: '.achievements .swiper-pagination',
        clickable: true
      },
      navigation: {
        nextEl: '.achievements .swiper-button-next',
        prevEl: '.achievements .swiper-button-prev'
      }
    })
  }
}
</script>
<style lang="sass" scoped>
.v-application--is-rtl
  .banner-item-image
    position: relative
    overflow: visible
  .white-absolute-container
    position: absolute
    width: 140px
    height: 55px
    bottom: -25px
    right: 10px
    background: #fff
    *
      position: absolute
      width: 78%
      left: 0
      right: 0
      margin: auto
      top: 0
      bottom: 0
.v-application--is-ltr
  .banner-item-image
    position: relative
    overflow: visible
  .white-absolute-container
    position: absolute
    width: 140px
    height: 55px
    bottom: -25px
    left: 10px
    background: #fff
    *
      position: absolute
      width: 78%
      left: 0
      right: 0
      margin: auto
      top: 0
      bottom: 0
.text-subtitle-1
  color: $accent
  font-size: 0.9em !important
  font-weight: 500
  font-family: inherit !important
.paragraph
  color: #80969e !important
  font-size: 0.9em
  //max-width: 28ch
  line-height: 1.8
  overflow: hidden
  display: -webkit-box
  -webkit-line-clamp: 5
  -webkit-box-orient: vertical
.swiper-slide
  border-radius: 3px
  overflow: hidden
.v-sheet.v-card
  transition: all 0.5s
.v-sheet.v-card:hover
  box-shadow: 0 2px 34px 0 rgba(65, 79, 85, 0.11) !important
</style>


