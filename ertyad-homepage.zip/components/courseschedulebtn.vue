<template lang="pug">
  v-row(justify='space-around')
    v-col(cols='auto')
      v-dialog(transition='dialog-bottom-transition' max-width='1000')
        template(v-slot:activator='{ on, attrs }')
          v-btn( v-bind='attrs' v-on='on' text='' @='dialog.value = false' class="ma-2" outlined color="primary"
          )
            v-icon( right color="accent" dark )
              | mdi-calendar
            | {{ $t('login.CourseSchedule') }}
        template(v-slot:default='dialog')
          v-card
            v-card-text.text-h2.pt-2.pr-2.pl-2.pb-0.text-center
              div
                v-row.fill-height
                  v-col
                    v-sheet(height='600')
                      // Event details menu
                      v-menu(v-model='selectedOpen' :close-on-content-click='false' :activator='selectedElement' offset-x='')
                        v-card(min-width='200px')
                          v-toolbar(color='#11bcce' dark='')
                            v-toolbar-title.mx-5
                              | {{ selectedEvent.name }}
                          v-card-text
                            .text-center
                              | {{ selectedEventStart }}
                              | to
                              | {{ selectedEventEnd }}
                            a( :href='selectedEvent.link' target='_blank')
                              v-btn(text='' color='primary' )
                                | download
                      v-calendar(:events='events' color='#fbae10' event-color='#11bcce' @click:day='viewDay' @click:event='showEvent' v-model='focus' :type='type' now='2022-08-21')
</template>
<script>
import { format } from 'date-fns'

export default {
  name: 'App',
  data: () => {
    return {
      focus: '',
      type: 'month',
      selectedOpen: false,
      selectedElement: undefined,
      selectedEvent: {},
      events: [
        {
          name: 'Course 1',
          start: '2022-08-10',
          timed: false,
          link: '/calender/LTIDocumentation.pdf'
        },
        {
          name: 'Course 2',
          start: '2022-08-04',
          end: '2022-08-04',
          link: '/calender/LTIDocumentation.pdf'
        },
        {
          name: 'Course 3',
          start: '2022-08-08T05:00:00',
          end: '2022-08-08T07:00:00',
          timed: true,
          link: '/calender/LTIDocumentation.pdf'
        },
        {
          name: 'Course 4',
          start: '2022-08-14T08:00:00',
          end: '2022-08-14T10:00:00',
          timed: true,
          link: '/calender/LTIDocumentation.pdf'
        }
      ]
    }
  },
  methods: {
    viewDay ({ date }) {
      this.focus = date
      this.type = 'day'
    },
    showEvent ({ nativeEvent, event }) {
      const open = () => {
        this.selectedEvent = event
        this.selectedElement = nativeEvent.target
        requestAnimationFrame(() =>
          requestAnimationFrame(
            () => (this.selectedOpen = true)
          )
        )
      }
      if (this.selectedOpen) {
        this.selectedOpen = false
        requestAnimationFrame(() =>
          requestAnimationFrame(() => open())
        )
      } else {
        open()
      }
      nativeEvent.stopPropagation()
    }
  },
  computed: {
    selectedEventStart () {
      return (
        (this.selectedEvent &&
          this.selectedEvent.start &&
          format(
            new Date(this.selectedEvent.start),
            'h:mm a'
          )) ||
        '12:00 AM'
      )
    },
    selectedEventEnd () {
      return (
        (this.selectedEvent &&
          this.selectedEvent.end &&
          format(
            new Date(this.selectedEvent.end),
            'h:mm a'
          )) ||
        '12:00 AM'
      )
    }
  }
}
</script>
<style lang="sass" scoped>
.v-card__text
  direction: initial
</style>
