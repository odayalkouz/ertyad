<template lang="pug">
  .swiper-container
    .swiper-wrapper
      .swiper-slide(
        v-for="(course, i) in courses"
        :key="i"
      )
        v-card.card.mb-14.d-flex.flex-column(
        )
          v-list-item(three-line='')
            v-list-item-content
              div.type
                a( v-html="course.type" )
              v-list-item-title(
                v-html="course.name"
              )
              v-list-item-subtitle
                p
                  | {{ course.caption }}
            v-list-item-avatar.ma-0(
              size='135'
              color='grey'
              tile)
              v-img(
                :src="course.imageSrc || defaultImage"
                :alt="course.alt || course.name"
              )
    .swiper-pagination
    .swiper-button-prev
    .swiper-button-next
</template>
<script>
// eslint-disable-next-line import/no-named-as-default
import Swiper, { Navigation, Pagination } from 'swiper'
import 'swiper/swiper-bundle.css'
Swiper.use([Navigation, Pagination])
export default {
  name: 'SliderCourses',
  props: {
    courses: {
      type: Array,
      default () {
        return []
      }
    }
  },
  data () {
    return {
      swiper: null,
      defaultImage: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/avatars/avatar.png'
    }
  },
  mounted () {
    const breakpoints = {}
    breakpoints[this.$vuetify.breakpoint.thresholds.sm] = {
      slidesPerView: 3,
      slidesPerGroup: 3
    }
    breakpoints[this.$vuetify.breakpoint.thresholds.xs] = {
      slidesPerView: 2,
      slidesPerGroup: 2
    }
    this.swiper = new Swiper('.TabsContents .swiper-container', {
      slidesPerView: 1,
      slidesPerGroup: 1,
      breakpoints,
      spaceBetween: 20,
      pagination: {
        el: '.TabsContents .swiper-pagination',
        clickable: true
      },
      navigation: {
        nextEl: '.TabsContents .swiper-button-next',
        prevEl: '.TabsContents .swiper-button-prev'
      }
    })
  }
}
</script>
<style lang="sass" scoped>
.card
  .v-list-item__content
    padding: 0 1rem
    .type
      a
        background-color: #02b6b321
        width: 81px
        height: 24px
        padding: 5px 20px
        border-radius: 14px
        color: $accent
        font-size: 0.7em
    .v-list-item__title
      font-weight: 800
      line-height: 1.3
    .v-list-item-subtitle
      color: #778aa1
      font-weight: 500
      font-size: 0.8rem
.v-application--is-rtl
  .v-sheet.v-card
    border-radius: 5px !important
    direction: ltr
    text-align: right
  .v-list-item
    padding-right: 0
    overflow: hidden
.v-application--is-ltr
  .v-sheet.v-card
    border-radius: 5px !important
    direction: rtl
    text-align: left
  .v-list-item
    padding-left: 0
    overflow: hidden
</style>


