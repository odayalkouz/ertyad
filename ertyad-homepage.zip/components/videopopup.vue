<template lang="pug">
  v-row(justify='space-around')
    v-col(cols='auto')
      v-dialog(transition='dialog-bottom-transition' max-width='800')
        template(v-slot:activator='{ on, attrs }')
          v-btn( v-bind='attrs' v-on='on' text='' @='dialog.value = false' class="ma-2" outlined color="primary"
          )
            v-icon( right color="accent" dark )
              | mdi-play-circle-outline
            | {{ $t('WhatClientSay.MeetingsWithEtiyadtTainees') }}
        template(v-slot:default='dialog')
          v-card
            v-card-text.text-h2.pt-2.pr-2.pl-2.pb-0
              iframe(width='100%' height='480' src='https://www.youtube.com/embed/W3uHu6N4Tp4' title='YouTube video player' frameborder='0' allow='accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture' allowfullscreen='')
</template>
<script>
import cfg from '@/project.config'
export default {
  data () {
    return {
      video: cfg.video
    }
  }
}
</script>
<style lang="sass" scoped>

</style>
