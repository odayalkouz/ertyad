<template lang="pug">
div(class="section")
  v-container.py-0(
    :class="`container--width-${containerWidth}`"
  )
    v-row.ma-0.pa-0.justify-center
      v-col.ma-0.pa-0(
        :cols="12"
      )
        slot(name="heading")
      v-col.ma-0.pa-0(
        :cols="12"
      )
        slot
</template>
<script>
const widths = ['slim', 'default', 'wide']

export default {
  name: 'AppSection',
  props: {
    containerWidth: {
      type: String,
      required: false,
      default: 'default',
      validate: width => widths.includes(width)
    }
  }
}
</script>
<style lang="sass" scoped>
  .section
    .heading--xl
      opacity: 0
      transition: all 0.9s
      transform: translateX(100%)
    &.active
      .heading--xl
        opacity: 1
        transform: translateX(0)

  .container--width-slim
    max-width: 50rem !important
</style>
