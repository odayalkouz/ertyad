<template lang="pug">
  ul.media
    li
      a.media__link.twitter(
        :href="twitter"
        target="_blank"
      )
        v-icon mdi-twitter
    li
      a.media__link.youtube(
        :href="Youtube"
        target="_blank"
      )
        v-icon mdi-youtube
    li
      a.media__link.instagram(
        :href="instagram"
        target="_blank"
      )
        v-icon mdi-instagram
    li
      a.media__link.linkedin(
        :href="linkedin"
        target="_blank"
      )
</template>
<script>
import cfg from '@/project.config'
export default {
  name: 'AppMedia',
  data () {
    return {
      linkedin: cfg.media.linkedin,
      twitter: cfg.media.twitter,
      Youtube: cfg.media.Youtube,
      instagram: cfg.media.instagram
    }
  }
}
</script>
<style lang="sass" scoped>
.media
  display: flex
  gap: 1.125rem
  padding: 0
  .v-icon
    color: inherit
  &__link
    width: 1.2em
    height: 1.2em
    border-radius: 50%
    display: flex
    align-items: center
    justify-content: center
    font-size: 2rem
    background-color: rgba(107, 131, 140, 0.5)
    color: $background
    text-decoration: none
    transition: all 0.5s
    &.linkedin
      background-image: url("https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/icons/linkedin.svg")
      background-size: .6em
      background-position: center
      background-repeat: no-repeat
.linkedin:hover
  background-color: #0a66c2
.youtube:hover
  background: #ff0000
.twitter:hover
  background: #1da1f2
.instagram:hover
  background: -webkit-radial-gradient(30% 107% ,circle, #fdf497 0%, #fdf497 5%, #fd5949 45%, #d6249f 60%, #285AEB 90%)
  background: -o-radial-gradient(30% 107% ,circle, #fdf497 0%, #fdf497 5%, #fd5949 45%, #d6249f 60%, #285AEB 90%)
  background: radial-gradient(circle at 30% 107%, #fdf497 0%, #fdf497 5%, #fd5949 45%, #d6249f 60%, #285AEB 90%)
  background: -webkit-radial-gradient(circle at 30% 107%, #fdf497 0%, #fdf497 5%, #fd5949 45%, #d6249f 60%, #285AEB 90%)
@media screen and (max-width: $sm)
  .media
    &__link
      font-size: 1.9rem
</style>
