<template lang="pug">
  footer.app-footer
    v-container.app-footer__container
      .app-footer__contact-data
        a.app-footer__link.heading--sm.call-us.mb-12(
          :href="`tel:${phone}`"
          target="_blank"
          v-html="$t('contact.phone', {phone})"
        )
        app-media.app-footer__media.mb-12
        .app-footer__copyright.paragraph
          | {{ $t('main.copyright', {year}) }}
      div.leftside
        h2(
          v-html="$t('main.heading')"
        )
        .app-footer__nav-group.mt-8
          a.app-footer__link(
            v-for="link in FooterLinks"
            :href="link.to"
          ) {{ $t(link.text) }}
      div.app-footer__heading
        nuxt-link(to="/")
          img.logo(
            :src='logoWhite'
            :alt='ertyadAlt'
            width='130'
            height='42'
          )
        p.paragraph.mt-6( v-html="$t('contact.aboutErtyad')")
        app-payment.mt-8
</template>
<script>
import cfg from '@/project.config'
import AppLogo from './logo'
import AppMedia from './media'
import AppPayment from './payment'
export default {
  name: 'AppFooter',
  components: { AppPayment, AppMedia, AppLogo },
  data () {
    return {
      ertyadAlt: cfg.metaContent.ertyad,
      logo: cfg.logo.logoColor,
      logoWhite: cfg.logo.logoWhite,
      phone: cfg.contact.phone,
      year: new Date().getFullYear(),
      FooterLinks: [
        {
          text: 'navFooter.About',
          to: '/aboutus#about'
        },
        {
          text: 'navFooter.Coaches',
          to: '/aboutus#our-trainees'
        },
        {
          text: 'navLevel.caseStudy',
          to: '/casestudy'
        },
        {
          text: 'navFooter.managementTeam',
          to: '/aboutus#our-managment'
        },
        {
          text: 'navFooter.Blog',
          to: '/blog'
        },
        {
          text: 'navFooter.AchievementsAndFigures',
          to: '/#achievements'
        },
        {
          text: 'navFooter.News',
          to: '/news'
        },
        {
          text: 'navFooter.contactUs',
          to: '/contact-us'
        },
        {
          text: 'navFooter.privacyPolicy',
          to: 'https://training.ertyad.com/ar/p/privacy'
        },
        {
          text: 'navFooter.TermsAndConditions',
          to: 'https://training.ertyad.com/ar/p/terms'
        },
        {
          text: 'navFooter.TechnicalSupportPolicy',
          to: 'https://training.ertyad.com/ar/p/technical_support'
        }
      ]
    }
  }
}
</script>
<style lang="sass" scoped>
.app-footer
  background: url('https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/footer/footer-right.png') no-repeat right, url('https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/footer/footer-left.png') no-repeat left
  background-color: $primary
  background-size: contain
  color: $background
  overflow: hidden
  position: relative
  padding-top: 6rem
  padding-bottom: 6rem
  @media screen and (max-width: $sm)
    background-position: bottom
    background-size: 100%
  *
    color: inherit
  &__container
    display: grid
    row-gap: 2.25rem
    align-items: start
    grid-template-columns: repeat(2, 1fr) max-content
    grid-template-areas: 'heading leftside contact-data'
  &__contact-data
    grid-area: contact-data
  &__copyright
    margin-bottom: .25em
  &__heading
    grid-area: heading
    &:first-line
      font-size: 1.1em
      font-weight: 700
    p
      max-width: 30ch
      line-height: 2.2em
    h2
      font-size: 1.8rem
      font-weight: 900
      line-height: 1.2em
  &__nav
    display: flex
    flex-wrap: wrap
    gap: 2rem
    align-items: flex-end
    @media only screen and (min-width: $sm)
      gap: 6.25rem
  &__nav-group
    gap: 1rem
    display: grid
    grid-template-columns: repeat(2, 1fr)
    @media only screen and (min-width: $xs)
      gap: 0.9rem
    &--sm-horizontal
      @media only screen and (min-width: $xs)
        flex-direction: row
        gap: 5rem
  &__link
    display: block
    text-decoration: none
    margin-bottom: .25em
    transition: opacity .3s ease
    font-size: 0.9rem
    &:hover
      opacity: .7
    &.call-us
      background-image: url('https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/icons/callus.svg')
      background-size: 2em
      background-position: right
      background-repeat: no-repeat
      padding-right: 2.3em
      padding-left: 2.3em
      font-size: 1.5rem !important
      direction: ltr
      text-align: right
      span
        color: $accent !important
@media screen and (max-width: $md)
  .app-footer
    &__container
      row-gap: 3rem
      grid-template-columns: 1fr max-content
      grid-template-areas: 'heading heading heading' 'leftside leftside leftside' 'contact-data contact-data contact-data'
@media screen and (max-width: $sm)
  .app-footer
    padding-top: 3rem
    padding-bottom: 3rem
    &__container
      row-gap: 2rem
    &__heading
      font-size: 1.25rem
.v-application--is-ltr
  .call-us
    background-position: left !important
    text-align: left !important
</style>
