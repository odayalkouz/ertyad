<template lang="pug">
  nuxt-link(to="/")
    img.logo(
      :src='logo'
      :alt='ertyadAlt'
      width='138px'
      height='55px'
      )
</template>
<script>
import cfg from '@/project.config'
export default {
  name: 'AppLogo',
  data () {
    return {
      ertyadAlt: cfg.metaContent.ertyad,
      logo: cfg.logo.logoColor
    }
  }
}
</script>
<style lang="sass" scoped>
*
  transition: all $default-transition-time $default-transition-function
.v-application--is-ltr
  .logo
    margin-top: 0.6em
    margin-right: 40px
.v-application--is-rtl
  .logo
    margin-top: 0.4em
    margin-left: 40px

</style>
