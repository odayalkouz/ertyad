<template lang="pug">
  v-app-bar.app-header(
    app
    color="#fff"
    height="80px"
    :class="{'app-header--scrolled': isPageScrolled}"
  )
    v-container.d-flex.align-center.py-0
      logo(
        size="100"
        :isWhite="!isPageScrolled"
      )
      app-nav.me-auto(
        :isPageScrolled="isPageScrolled"
      )
      .app-header__locale-switcher
        nuxt-link.app-footer__locale-link.heading--xs.me-2(
          v-for="locale in locales"
          :key="locale"
          :to="switchLocalePath(locale)"
          v-html="locale == 'en' ? 'English' : 'Arabic'"
        )
      a(:href="login" class="d-none d-sm-flex d-md-flex  d-md-none d-lg-flex d-sm-flex")
        v-btn(
          depressed
          color="accent"
          v-html="$t('login.loginBtn')"
          )
      a()
        CourseScheduleBtn(class="d-none d-sm-flex d-md-flex d-md-none d-lg-flex d-sm-flex")
</template>
<script>
/* eslint-disable nuxt/no-globals-in-created */
import CourseScheduleBtn from '@/components/courseschedulebtn'
import AppNav from '@/components/app/nav'
import Logo from '@/components/app/logo'
import cfg from '@/project.config'

export default {
  name: 'AppHeader',
  components: {
    CourseScheduleBtn,
    AppNav,
    Logo
  },
  data () {
    return {
      isPageScrolled: false,
      login: cfg.loginLinks.link1,
      Schedule: cfg.loginLinks.link2
    }
  },
  computed: {
    locales () {
      return cfg.locale.list.map(locale => locale.code)
    }
  }
}
</script>
<style lang="sass" scoped>
.app-header
  &__locale-switcher
    .nuxt-link-active
     display: none
    a
     text-decoration: none !important
     font-size: 1rem
</style>
