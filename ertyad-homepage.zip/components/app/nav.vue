<template lang="pug">
  nav.app-nav
    v-app-bar-nav-icon.app-nav__open-icon.ms-n9(
      v-if="isMenuCollapsed"
      @click="isOpen = true"
    )
    v-navigation-drawer.app-nav__drawer(
      v-if="isMenuCollapsed"
      v-model="isOpen"
      fixed
      temporary
      hide-overlay
      height="auto"
      width="100vw"
    )
      v-icon.app-nav__close-icon.py-8.px-9.ms-n4(
        color="primary"
        @click="isOpen = false"
      ) mdi-close

      v-list.app-nav__list.pt-0.pb-8(
        color="transparent"
      )
        // v-list-item.justify-center(
        v-list-item(
          v-for="(link, i) in links"
          :key="i"
        )
          a(:href="link.to")
            v-btn.app-nav__link.px-2(
              :href="link.href"
            ) {{ $t(link.text) }}

      v-list-group(prepend-icon='mdi-information-outline' no-action='' class="d-none")
        template(v-slot:activator='')
          v-list-item-content
            v-list-item-title Club Info
        v-list-item
          v-list-item-action
            v-icon mdi-contacts
          v-list-item-content
            v-list-item-title Contacts
        v-list-item
          v-list-item-action
            v-icon mdi-stadium
          v-list-item-content
            v-list-item-title Grounds
        v-list-item
          v-list-item-action
            v-icon mdi-home-circle
          v-list-item-content
            v-list-item-title Clubhouse
        v-list-item
          v-list-item-action
            v-icon mdi-history
          v-list-item-content
            v-list-item-title History

    v-list.app-nav__list.d-flex.align-center(
      v-else
      color="transparent"
    )
      v-list-item.px-0.px-lg-2(
        v-for="(link, i) in links"
        :key="i"
        :class="link.custom"
      )
        v-btn.app-nav__link.px-2(
          :class="{'ps-0': !i}"
          :to="link.to"
          :href="link.href"

        ) {{ $t(link.text) }}
      v-menu(open-on-hover='' offset-y='')
        template(v-slot:activator='{ on }')
          v-btn.px-6.custom-icon(text='' v-on='on')
            | {{ $t('navLevel.developmentResources') }}
            v-icon(right)
              | mdi-arrow-down-drop-circle-outline
        v-list
          v-list-item(
            v-for="(link, i) in linksLevel"
            :key="i")
            v-list-item-title
              v-btn.app-nav__link.px-2(
                :class="{'ps-0': !i}"
                :to="link.to"
                :href="link.href"
              ) {{ $t(link.text) }}
</template>
<script>
export default {
  name: 'AppNav',
  data () {
    return {
      isOpen: false,
      links: [
        {
          text: 'nav.MainPage',
          to: '/',
          custom: ''
        },
        {
          text: 'nav.whoWeAre',
          to: '/aboutus',
          custom: ''
        },
        {
          text: 'nav.ourServices',
          to: '/#support',
          custom: ''
        },
        {
          text: 'nav.ourPartners',
          to: '/#partners',
          custom: ''
        },
        {
          text: 'nav.developmentResources',
          to: '',
          custom: 'd-sm-none'
        },
        {
          text: 'login.loginBtn',
          to: 'https://training.ertyad.com/ar/login',
          custom: 'd-sm-none'
        }
        // ,
        // {
        //   text: 'login.CourseSchedule',
        //   to: 'https://training.ertyad.com/ar/login',
        //   custom: 'd-sm-none'
        // }
      ],
      linksLevel: [
        {
          text: 'navLevel.caseStudy',
          to: '/case-studies'
        },
        {
          text: 'navLevel.whitePapers',
          to: '/whitepaper'
        },
        {
          text: 'navLevel.blog',
          to: '/blog'
        },
        {
          text: 'navLevel.ertyadNews',
          to: '/news'
        }
      ]
    }
  },
  computed: {
    isMenuCollapsed () {
      return this.$vuetify.breakpoint.smAndDown
    }
  }
}
</script>
<style lang="sass" scoped>
.app-nav
  .v-list-item
    flex-basis: auto
  &__link
    color: $primary
    background: transparent !important
    box-shadow: none !important
    text-decoration: none
    font-weight: 500
    font-size: 0.9rem !important
    white-space: nowrap
    transition: all $default-transition-time $default-transition-function
    &::before,
    &::after
      content: none
  .v-app-bar__nav-icon
    color: $primary !important

.app-header--scrolled .app-nav
  &__link
    color: $primary
  .v-app-bar__nav-icon
    color: $primary !important

@media screen and (max-width: $md)
  .app-nav
    &__drawer
      transform: translate(0, 0) !important
      &:not(.v-navigation-drawer--open)
        transform: translate(0, -100%) !important
    &__link
      color: $primary
      font-size: 4rem
      line-height: 1.8em
@media screen and (max-width: $sm)
  .app-nav
    &__link
      font-size: 3rem
.v-application--is-rtl .v-btn
  letter-spacing: 0 !important

.v-application--is-ltr .custom-icon
  direction: rtl !important
.v-application--is-rtl .custom-icon
  direction: ltr !important
</style>
