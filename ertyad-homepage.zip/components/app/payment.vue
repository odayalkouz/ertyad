<template lang="pug">
  ul.payment
    li
      a.payment__icon.payment1
    li
      a.payment__icon.payment2
    li
      a.payment__icon.payment3
</template>
<script>
export default {
  name: 'Payment'
}
</script>
<style lang="sass" scoped>
.payment
  display: flex
  gap: 1.125rem
  padding: 0
  .v-icon
    color: inherit
  &__icon
    width: 0.9em
    height: 0.9em
    display: flex
    align-items: center
    justify-content: center
    font-size: 2rem
    padding: 0 0.8em
    background-color: $background
    text-decoration: none
    border-radius: 5px
    transition: all 0.5s
    cursor: default
    &.payment1
      background-image: url('https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/icons/1.svg')
      background-size: 70%
      background-position: center
      background-repeat: no-repeat
    &.payment2
      background-image: url("https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/icons/2.svg")
      background-size: 55%
      background-position: center
      background-repeat: no-repeat
    &.payment3
      background-image: url("https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/icons/3.svg")
      background-size: 70%
      background-position: center
      background-repeat: no-repeat
@media screen and (max-width: $sm)
  .payment
    &__icon
      font-size: 1.9rem
</style>
