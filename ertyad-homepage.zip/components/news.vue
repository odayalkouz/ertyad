<template lang="pug">

  .swiper-slide
    nuxt-link.oday( :to="'news/'+new1.id")
      v-hover(v-slot='{ hover }')
        v-card.mx-auto(color='grey lighten-4' max-width='600')
          v-img(
            :aspect-ratio='16/9'
            :src="new1.imageSrc || defaultImage"
            :alt="new1.alt || new1.name"
          )
            v-expand-transition
              .d-flex.transition-fast-in-fast-out.orange.darken-2.v-card--reveal.text-h2.white--text(v-if='hover' style='height: 100%;')
                | أخبار ارتياد
          v-card-text.pt-6(style='position: relative;')
            h3.text-h4.font-weight-light.orange--text.mb-2(
              v-html="new1.name"
            )
            h3.text-h4.font-weight-light.orange--text.mb-2(
              v-html="new1.id")
            .font-weight-light.text-h6.mb-2(
              v-html="new1.paragraph"
            )
</template>

<script>

// eslint-disable-next-line import/no-named-as-default
import Swiper, { Navigation, Pagination } from 'swiper'
import 'swiper/swiper-bundle.css'
import AppSection from '@/components/app/section'

Swiper.use([Navigation, Pagination])

export default {
  name: 'NewsPage',
  components: { AppSection },
  props: {
    news: {
      type: Array,
      required: true
    }
  }
}
</script>
<style lang="sass" scoped>
.paragraph
  color: #80969e !important
  font-size: 0.9em
  line-height: 1.8
  overflow: hidden
  display: -webkit-box
  -webkit-line-clamp: 5
  -webkit-box-orient: vertical
//min-height: 113px
.v-card
  border: solid 1px #d9d9d9
.v-application--is-rtl
  .paragraph
    text-align: right
.v-application--is-ltr
  .paragraph
    text-align: left
</style>


