<template lang="pug">
  v-card
    v-tabs(v-model='tab' background-color='accent-4' centered='' flat="false")
      v-tabs-slider.tabs-container
      v-tab.tabs-container__tab-item(
        v-for="(title, i) in TabsTitles"
        :key="i"
        :href="'#tab-' + i"
        )
        | {{ $t(title) }}
    v-tabs-items(v-model='tab')
      v-tab-item#tab-0
        v-card(flat='')
          v-card-text
            TabsSlider(:courses="courses1").mt-6
      v-tab-item#tab-1
        v-card(flat='')
          v-card-text
            TabsSlider(:courses="courses2").mt-6
      v-tab-item#tab-2
        v-card(flat='')
          v-card-text
            TabsSlider(:courses="courses3").mt-6
      v-tab-item#tab-3
        v-card(flat='')
          v-card-text
            TabsSlider(:courses="courses4").mt-6
    CourseScheduleBtn
</template>
<script>
import TabsSlider from '@/components/tabsslider'
import CourseScheduleBtn from '@/components/courseschedulebtn'
import { MediaCourses } from '@/media.config'
export default {
  components: { CourseScheduleBtn, TabsSlider },
  data () {
    return {
      tab: null,
      TabsTitles: [
        'Courses.title1', 'Courses.title2', 'Courses.title3', 'Courses.title4'
      ]
    }
  },
  computed: {
    courses1 () {
      const courseMedia = MediaCourses.images1
      return courseMedia.map((image, i) => {
        return {
          ...image,
          type: this.$t(`Courses.list1[${i}].type`),
          name: this.$t(`Courses.list1[${i}].name`),
          caption: this.$t(`Courses.list1[${i}].startDate`)
        }
      })
    },
    courses2 () {
      const courseMedia = MediaCourses.images2
      return courseMedia.map((image, i) => {
        return {
          ...image,
          type: this.$t(`Courses.list2[${i}].type`),
          name: this.$t(`Courses.list2[${i}].name`),
          caption: this.$t(`Courses.list2[${i}].startDate`)
        }
      })
    },
    courses3 () {
      const courseMedia = MediaCourses.images3
      return courseMedia.map((image, i) => {
        return {
          ...image,
          type: this.$t(`Courses.list3[${i}].type`),
          name: this.$t(`Courses.list3[${i}].name`),
          caption: this.$t(`Courses.list3[${i}].startDate`)
        }
      })
    },
    courses4 () {
      const courseMedia = MediaCourses.images4
      return courseMedia.map((image, i) => {
        return {
          ...image,
          type: this.$t(`Courses.list4[${i}].type`),
          name: this.$t(`Courses.list4[${i}].name`),
          caption: this.$t(`Courses.list4[${i}].startDate`)
        }
      })
    }
  }
}
</script>
<style lang="sass" scoped>
.tabs-container
  &__tab-item
    border-radius: 20px
    border: solid 1px #dee0e3
    background-color: #fff
    margin: 0 0.5rem
    color: rgba(0, 0, 0, 0.54)
.v-tab--active
  color: $accent !important
  box-shadow: 0 2px 34px 0 rgba(65, 79, 85, 0.11)
  border: solid 0
.v-tab:before
  border-radius: 20px
.v-tabs-slider-wrapper, .v-tabs-slider
  display: none !important
.v-sheet.v-card:not(.v-sheet--outlined)
  box-shadow: none !important
</style>

