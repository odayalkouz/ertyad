<template lang="pug">
  .swiper-container.slider
    .swiper-wrapper
      .swiper-slide(
        v-for="(item, i) in items"
        :key="i"
      )
        slot
          v-img.mx-auto(
            :src="item.imageSrc"
            :alt="item.alt"
            contain
            width="10rem"
            height="10rem"
          )
    .swiper-button-prev
    .swiper-button-next
</template>
<script>
import { Swiper, Navigation } from 'swiper'
import 'swiper/swiper-bundle.css'

Swiper.use([Navigation])

export default {
  name: 'Slider',

  props: {
    items: {
      type: Array,
      required: true
    },
    numberOfSliders: {
      type: Number,
      required: true
    }
  },
  data () {
    return {
      swiper: null
    }
  },
  mounted () {
    const breakpoints = {}
    breakpoints[this.$vuetify.breakpoint.thresholds.sm] = {
      slidesPerView: this.numberOfSliders,
      slidesPerGroup: this.numberOfSliders
    }

    this.swiper = new Swiper('.slider.swiper-container', {
      slidesPerView: 1,
      slidesPerGroup: 1,
      breakpoints,
      pagination: {
        el: '.slider .swiper-pagination',
        clickable: true
      },
      navigation: {
        nextEl: '.slider .swiper-button-next',
        prevEl: '.slider .swiper-button-prev'
      }
    })
  }
}
</script>
