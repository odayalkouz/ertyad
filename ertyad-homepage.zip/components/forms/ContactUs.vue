<template lang="pug">
  v-form.form.contact-us(
    action="https://formsubmit.co/o.alkouz@sajil.org"
    method="POST"
  )
    .contact-us__row.d-none
      v-text-field(
        type="hidden"
        name="_captcha"
        value="false")
    .contact-us__row.d-none
      v-text-field(
        type="hidden"
        name="_next"
        value="http://localhost:3000/contact-us"
        )
    .contact-us__row
      v-text-field(
        name="first-name"
        :label="$t('fields.firstName')"
        v-model="fields.firstName"
        :error-messages="getFieldErrors('firstName')"
        @input="$v.fields.firstName.$touch()"
        @blur="$v.fields.firstName.$touch()"
        outlined
      )
      v-text-field(
        name="last-name"
        :label="$t('fields.lastName')"
        v-model="fields.lastName"
        :error-messages="getFieldErrors('lastName')"
        @input="$v.fields.lastName.$touch()"
        @blur="$v.fields.lastName.$touch()"
        outlined
      )
    .contact-us__row
      v-text-field(
        name="email"
        type="email"
        :label="$t('fields.email')"
        v-model="fields.email"
        :error-messages="getFieldErrors('email')"
        @input="$v.fields.email.$touch()"
        @blur="$v.fields.email.$touch()"
        outlined
      )
      v-text-field(
        name="phone"
        :label="$t('fields.phone')"
        v-model="fields.phone"
        :error-messages="getFieldErrors('phone')"
        @input="$v.fields.phone.$touch()"
        @blur="$v.fields.phone.$touch()"
        outlined
      )
    v-text-field(
      name="subject"
      :label="$t('fields.subject')"
      v-model="fields.subject"
      :error-messages="getFieldErrors('subject')"
      @input="$v.fields.subject.$touch()"
      @blur="$v.fields.subject.$touch()"
      outlined
    )
    v-textarea(
      name="message"
      :label="$t('fields.message')"
      v-model="fields.message"
      :error-messages="getFieldErrors('message')"
      @input="$v.fields.message.$touch()"
      @blur="$v.fields.message.$touch()"
      no-resize
      outlined
    )
    v-btn(
      color="accent"
      large
      type="submit"
      target="_blank"
      :loading="isSending"
    ) {{ $t('actions.submit') }}

</template>

<script>
import { validationMixin } from 'vuelidate'
import { required, email } from 'vuelidate/lib/validators'
import { phone } from '@/lib/helpers/validation.helper'
import { sendForm } from '@/lib/sesrvices/contact-us'


export default {
  name: 'ContactUsForm',

  mixins: [validationMixin],

  data () {
    return {
      fields: {
        firstName: '',
        lastName: '',
        email: '',
        phone: '',
        subject: '',
        message: ''
      },
      isSending: false
    }
  },

  validations: {
    fields: {
      firstName: { required },
      lastName: { required },
      email: {
        required,
        email
      },
      phone: { required, phone },
      subject: { required },
      message: { required }
    }
  },

  methods: {
    getFieldErrors (name) {
      const errors = []

      if (!this.$v.fields[name].$dirty) { return errors }

      const errorTypes = Object.keys(this.$v.fields[name]).filter(type => type[0] !== '$')

      errorTypes.forEach((errorType) => {
        !this.$v.fields[name][errorType] && errors.push(this.$t(`fieldsErrors.${errorType}`, { fieldName: this.$t(`fields.${name}`) }))
      })

      return errors
    },

    onFormSubmit () {
      this.$v.$touch()

      if (this.$v.fields.$error) { return }

      this.isSending = true
      sendForm({})
        .then(() => {})
        .finally(() => {
          this.isSending = false
        })
    }
  }
}
</script>

<style lang="sass" scoped>

.contact-us__row
  display: flex
  gap: 1.5rem
  @media screen and (max-width: $md)
    display: block
</style>
