<template lang="pug">

  .swiper-container
    .swiper-wrapper
      .swiper-slide(
        v-for="(user, i) in users"
        :key="i"
      )
        v-card.card.rounded-xl.py-6.px-6.mb-14.d-flex.flex-column(
          elevation="0"
        )
          p.qoute {{ user.paragraph }}
          v-list-item(three-line='')
            v-list-item-content
              h3.heading--md(
                v-html="user.name"
              )
              v-list-item-subtitle
                p.paragraph.color-inherit.font-weight-normal
                  | {{ user.caption }}
            v-list-item-avatar(
              size='40'
              color='grey')
              v-img(
                :src="user.imageSrc || defaultImage"
                :alt="user.alt || user.name"
              )

    .swiper-pagination
    .swiper-button-prev
    .swiper-button-next
</template>
<script>
import { MediaCLient } from '@/media.config'
// eslint-disable-next-line import/no-named-as-default
import Swiper, { Navigation, Pagination } from 'swiper'
import 'swiper/swiper-bundle.css'
Swiper.use([Navigation, Pagination])
export default {
  name: 'what-client-say',
  data () {
    return {
      swiper: null,
      defaultImage: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/avatars/avatar.png'
    }
  },
  computed: {
    users () {
      const UsersMedia = MediaCLient.images
      return UsersMedia.map((image, i) => {
        return {
          ...image,
          name: this.$t(`WhatClientSay.list[${i}].name`),
          caption: this.$t(`WhatClientSay.list[${i}].caption`),
          paragraph: this.$t(`WhatClientSay.list[${i}].paragraph`)
        }
      }
      )
    }
  },
  mounted () {
    const breakpoints = {}

    breakpoints[this.$vuetify.breakpoint.thresholds.sm] = {
      slidesPerView: 2,
      slidesPerGroup: 2
    }
    breakpoints[this.$vuetify.breakpoint.thresholds.xs] = {
      slidesPerView: 2,
      slidesPerGroup: 2
    }
    this.swiper = new Swiper('.what-client-say .swiper-container', {
      slidesPerView: 1,
      slidesPerGroup: 1,
      breakpoints,
      spaceBetween: 50,
      pagination: {
        el: '.what-client-say .swiper-pagination',
        clickable: true
      },
      navigation: {
        nextEl: '.what-client-say .swiper-button-next',
        prevEl: '.what-client-say .swiper-button-prev'
      }
    })
  }
}
</script>
<style lang="sass" scoped>
.card
  .qoute
    padding: 1.7rem !important
    background: url('https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/icons/qoute.svg') no-repeat bottom left, url('https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/icons/qoute.svg') no-repeat top right
    background-size: 3.6%
    font-size: 0.9rem
  .v-list-item__content
    padding: 0 1rem
  h3
    margin-top: 0
    color: $accent
    font-weight: normal
    font-size: 0.9em
.v-application--is-rtl
  .v-sheet.v-card
    border-radius: 5px !important
    direction: ltr
    text-align: right
.v-application--is-ltr
  .v-sheet.v-card
    border-radius: 5px !important
    direction: rtl
    text-align: left
</style>


