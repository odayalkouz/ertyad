<template lang="pug">
  .card
    a.card__image-wrapper(
      :href="fileUrl"
      target="_blank"
    )
      .card__image-mask
        img.card__image( height="180"
          :alt="heading"
          :src="imageUrl"

        )
      v-btn.card__button(
        v-if="fileUrl"
        :href="fileUrl"
        target="_blank"
        icon
        small
      )
        v-icon(
          small
        ) mdi-download

    h2.heading--md.card__heading( :title="heading") {{ heading }}

    p(v-if="description" :title='description').card__description {{ description }}

</template>

<script>
export default {
  name: 'FileCard',

  props: {
    heading: {
      type: String,
      required: true
    },
    description: {
      type: String,
      required: false,
      default: ''
    },
    imageUrl: {
      type: String,
      required: true
    },
    fileUrl: {
      type: String,
      required: false,
      default: ''
    }
  }
}
</script>

<style lang="sass" scoped>
.card
  &__heading
    overflow: hidden
    display: -webkit-box
    -webkit-line-clamp: 1
    -webkit-box-orient: vertical
  &__image-wrapper
    display: flex
    align-items: center
    position: relative
    background-color: #F5F5F5
    border-radius: .75rem
    padding: 1rem
    &:hover
      .card__image
        transform: scale(1.2)
      .card__button
        opacity: 1

  &__image-mask
    display: block
    max-width: 100%
    border-radius: .375rem
    overflow: hidden

  &__image
    display: block
    max-width: 100%
    transition: .5s ease

  &__button
    position: absolute
    opacity: 0
    inset-block-end: 1.5rem
    inset-inline-start: 1.5rem
    background: $background

  &__description
    font-size: .875rem
    color: mix($primary, white, 50%)
    overflow: hidden
    display: -webkit-box
    -webkit-line-clamp: 5
    -webkit-box-orient: vertical
</style>
