// Headings and description should be the json pointers from transcriptions files.
// For example: 'main.heading' → 'Site Map' / 'خريطة الموقع'

export const caseStudies = [
  {
    id: '1',
    heading: 'caseStudies.list[0].heading',
    description: 'caseStudies.list[0].description',
    imageUrl: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/casestudies/1.jpg',
    fileUrl: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/casestudies/1.pdf'
  },
  {
    id: '2',
    heading: 'caseStudies.list[1].heading',
    description: 'caseStudies.list[1].description',
    imageUrl: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/casestudies/2.jpg',
    fileUrl: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/casestudies/2.pdf'
  },
  {
    id: '3',
    heading: 'caseStudies.list[2].heading',
    description: 'caseStudies.list[2].description',
    imageUrl: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/casestudies/3.jpg',
    fileUrl: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/casestudies/3.pdf'
  },
  {
    id: '4',
    heading: 'caseStudies.list[3].heading',
    description: 'caseStudies.list[3].description',
    imageUrl: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/casestudies/4.jpg',
    fileUrl: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/casestudies/4.pdf'
  },
  {
    id: '5',
    heading: 'caseStudies.list[4].heading',
    description: 'caseStudies.list[4].description',
    imageUrl: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/casestudies/5.jpg',
    fileUrl: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/casestudies/5.pdf'
  },
  {
    id: '6',
    heading: 'caseStudies.list[5].heading',
    description: 'caseStudies.list[5].description',
    imageUrl: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/casestudies/6.jpg',
    fileUrl: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/casestudies/6.pdf'
  },
  {
    id: '7',
    heading: 'caseStudies.list[6].heading',
    description: 'caseStudies.list[6].description',
    imageUrl: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/casestudies/7.jpg',
    fileUrl: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/casestudies/7.pdf'
  },
  {
    id: '8',
    heading: 'caseStudies.list[7].heading',
    description: 'caseStudies.list[7].description',
    imageUrl: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/casestudies/8.jpg',
    fileUrl: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/casestudies/8.pdf'
  },
  {
    id: '9',
    heading: 'caseStudies.list[8].heading',
    description: 'caseStudies.list[8].description',
    imageUrl: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/casestudies/9.webp',
    fileUrl: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/casestudies/9.pdf'
  },
  {
    id: '10',
    heading: 'caseStudies.list[9].heading',
    description: 'caseStudies.list[9].description',
    imageUrl: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/casestudies/10.jpg',
    fileUrl: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/casestudies/10.pdf'
  },
  {
    id: '11',
    heading: 'caseStudies.list[10].heading',
    description: 'caseStudies.list[10].description',
    imageUrl: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/casestudies/11.jpg',
    fileUrl: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/casestudies/11.pdf'
  },
  {
    id: '12',
    heading: 'caseStudies.list[11].heading',
    description: 'caseStudies.list[11].description',
    imageUrl: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/casestudies/12.jpg',
    fileUrl: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/casestudies/12.pdf'
  },
  {
    id: '13',
    heading: 'caseStudies.list[12].heading',
    description: 'caseStudies.list[12].description',
    imageUrl: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/casestudies/13.jpg',
    fileUrl: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/casestudies/13.pdf'
  }
]
