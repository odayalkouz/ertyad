module.exports = {
  bannerContent: {
    src: [
      'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/bannerSlider/1.png',
      'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/bannerSlider/2.jpg',
      'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/bannerSlider/3.png',
      'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/bannerSlider/4.jpg'
    ],
    btnSrc: [
      'src1',
      'src1',
      'https://training.ertyad.com/ar/login',
      '/blog'
    ]
  },
  support: {
    images: [
      'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/services/1.json',
      'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/services/2.json',
      'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/services/3.json'
    ]
  },
  aboutUs: {
    src: [
      '100',
      '700',
      '400',
      '200'
    ],
    titles: [
      '100',
      '700',
      '400',
      '200'
    ]
  },
  partners: {
    images: [
      {
        imageSrc: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/partners/1.png',
        alt: '1'
      },
      {
        imageSrc: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/partners/2.png',
        alt: '2'
      },
      {
        imageSrc: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/partners/3.png',
        alt: '3'
      },
      {
        imageSrc: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/partners/4.png',
        alt: '4'
      },
      {
        imageSrc: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/partners/5.png',
        alt: '5'
      },
      {
        imageSrc: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/partners/6.png',
        alt: '6'
      },
      {
        imageSrc: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/partners/7.png',
        alt: '7'
      }
    ]
  },
  clients: {
    images: [
      {
        imageSrc: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/clients/1.png',
        alt: 'COC'
      },
      {
        imageSrc: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/clients/2.png',
        alt: 'ECS'
      },
      {
        imageSrc: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/clients/3.png',
        alt: 'Saudi Bar Association'
      },
      {
        imageSrc: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/clients/4.png',
        alt: 'Taqeem'
      },
      {
        imageSrc: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/clients/5.png',
        alt: 'Araamis'
      },
      {
        imageSrc: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/clients/6.png',
        alt: 'Business Noura'
      },
      {
        imageSrc: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/clients/7.png',
        alt: 'Dale Carnegie'
      },
      {
        imageSrc: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/clients/8.png',
        alt: 'Dale Carnegie'
      },
      {
        imageSrc: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/clients/9.png',
        alt: 'Dale Carnegie'
      },
      {
        imageSrc: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/clients/10.png',
        alt: 'Dale Carnegie'
      },
      {
        imageSrc: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/clients/11.png',
        alt: 'Dale Carnegie'
      },
      {
        imageSrc: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/clients/12.png',
        alt: 'Dale Carnegie'
      },
      {
        imageSrc: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/clients/13.png',
        alt: 'Dale Carnegie'
      },
      {
        imageSrc: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/clients/14.png',
        alt: 'Dale Carnegie'
      },
      {
        imageSrc: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/clients/15.png',
        alt: 'Dale Carnegie'
      },
      {
        imageSrc: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/clients/16.png',
        alt: 'Dale Carnegie'
      },
      {
        imageSrc: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/clients/17.png',
        alt: 'Dale Carnegie'
      },
      {
        imageSrc: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/clients/18.png',
        alt: 'Dale Carnegie'
      },
      {
        imageSrc: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/clients/19.png',
        alt: 'Dale Carnegie'
      },
      {
        imageSrc: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/clients/20.png',
        alt: 'Dale Carnegie'
      },
      {
        imageSrc: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/clients/21.png',
        alt: 'Dale Carnegie'
      },
      {
        imageSrc: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/clients/22.png',
        alt: 'Dale Carnegie'
      },
      {
        imageSrc: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/clients/23.png',
        alt: 'Dale Carnegie'
      },
      {
        imageSrc: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/clients/24.png',
        alt: 'Dale Carnegie'
      },
      {
        imageSrc: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/clients/25.png',
        alt: 'Dale Carnegie'
      },
      {
        imageSrc: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/clients/26.png',
        alt: 'Dale Carnegie'
      },
      {
        imageSrc: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/clients/27.png',
        alt: 'Dale Carnegie'
      },
      {
        imageSrc: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/clients/28.png',
        alt: 'Dale Carnegie'
      },
      {
        imageSrc: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/clients/29.png',
        alt: 'Dale Carnegie'
      },
      {
        imageSrc: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/clients/30.png',
        alt: 'Dale Carnegie'
      }
    ]
  },
  achievements: {
    images: [
      {
        imageSrc: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/achievements/1-top.jpg',
        logo: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/achievements/1.png',
        alt: 'alt1'
      },
      {
        imageSrc: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/achievements/2-top.jpg',
        logo: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/achievements/2.png',
        alt: 'alt1'
      },
      {
        imageSrc: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/achievements/3-top.jpg',
        logo: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/achievements/3.png',
        alt: 'alt1'
      }
    ]
  },
  MediaCLient: {
    images: [
      {
        imageSrc: '',
        alt: ''
      },
      {
        imageSrc: '',
        alt: ''
      },
      {
        imageSrc: '',
        alt: ''
      },
      {
        imageSrc: '',
        alt: ''
      }
    ]
  },
  MediaCourses: {
    images1: [
      {
        imageSrc: 'https://d2b3qk12wfl0ga.cloudfront.net/s/img/ertya/sjil-web-12.jpg',
        alt: ''
      },
      {
        imageSrc: 'https://ctertya-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/01-25.jpg',
        alt: ''
      },
      {
        imageSrc: 'https://d2b3qk12wfl0ga.cloudfront.net/s/img/ertya/sjilll-web-10.jpg',
        alt: ''
      },
      {
        imageSrc: '',
        alt: ''
      },
      {
        imageSrc: '',
        alt: ''
      },
      {
        imageSrc: '',
        alt: ''
      }
    ],
    images2: [
      {
        imageSrc: 'https://d2b3qk12wfl0ga.cloudfront.net/s/img/ertya/sjil-web-12.jpg',
        alt: ''
      },
      {
        imageSrc: 'https://ctertya-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/01-25.jpg',
        alt: ''
      },
      {
        imageSrc: 'https://d2b3qk12wfl0ga.cloudfront.net/s/img/ertya/sjilll-web-10.jpg',
        alt: ''
      },
      {
        imageSrc: '',
        alt: ''
      },
      {
        imageSrc: '',
        alt: ''
      },
      {
        imageSrc: '',
        alt: ''
      }
    ],
    images3: [
      {
        imageSrc: 'https://d2b3qk12wfl0ga.cloudfront.net/s/img/ertya/sjil-web-12.jpg',
        alt: ''
      },
      {
        imageSrc: 'https://ctertya-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/01-25.jpg',
        alt: ''
      },
      {
        imageSrc: 'https://d2b3qk12wfl0ga.cloudfront.net/s/img/ertya/sjilll-web-10.jpg',
        alt: ''
      },
      {
        imageSrc: '',
        alt: ''
      },
      {
        imageSrc: '',
        alt: ''
      },
      {
        imageSrc: '',
        alt: ''
      }
    ],
    images4: [
      {
        imageSrc: 'https://d2b3qk12wfl0ga.cloudfront.net/s/img/ertya/sjil-web-12.jpg',
        alt: ''
      },
      {
        imageSrc: 'https://ctertya-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/01-25.jpg',
        alt: ''
      },
      {
        imageSrc: 'https://d2b3qk12wfl0ga.cloudfront.net/s/img/ertya/sjilll-web-10.jpg',
        alt: ''
      },
      {
        imageSrc: '',
        alt: ''
      },
      {
        imageSrc: '',
        alt: ''
      },
      {
        imageSrc: '',
        alt: ''
      }
    ]
  },
  ourManagment: {
    images: [
      {
        imageSrc: 'https://d311qk7d4dpm8d.cloudfront.net/wp-content/uploads/2018/11/29155359/team_abdullah.jpg',
        alt: ''
      },
      {
        imageSrc: '',
        alt: ''
      },
      {
        imageSrc: '',
        alt: ''
      }
    ]
  },
  ourTrainees: {
    images: [
      {
        imageSrc: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/trainee/1.jpeg',
        alt: 'أحمد خطاب'
      },
      {
        imageSrc: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/trainee/2.png',
        alt: 'محمد عصام الدين'
      },
      {
        imageSrc: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/trainee/3.jpeg',
        alt: ''
      },
      {
        imageSrc: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/trainee/4.png',
        alt: ''
      },
      {
        imageSrc: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/trainee/5.jpeg',
        alt: ''
      },
      {
        imageSrc: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/trainee/6.jpeg',
        alt: ''
      },
      {
        imageSrc: '',
        alt: ''
      },
      {
        imageSrc: '',
        alt: ''
      },
      {
        imageSrc: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/trainee/9.png',
        alt: ''
      },
      {
        imageSrc: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/trainee/10.jpeg',
        alt: ''
      },
      {
        imageSrc: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/trainee/11.jfif',
        alt: ''
      },
      {
        imageSrc: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/trainee/12.png',
        alt: ''
      },
      {
        imageSrc: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/trainee/13.jpeg',
        alt: ''
      },
      {
        imageSrc: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/trainee/14.png',
        alt: ''
      },
      {
        imageSrc: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/trainee/15.png',
        alt: ''
      },
      {
        imageSrc: '',
        alt: ''
      },
      {
        imageSrc: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/trainee/16.png',
        alt: ''
      },
      {
        imageSrc: '',
        alt: ''
      }
    ]
  },
  whitepaper: {
    files: [
      {
        src: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/whitepaper/CCL Digital-Learning-Success-White-Paper-1.pdf'
      },
      {
        src: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/whitepaper/Developing Resilience In The Workplace White Paper.pdf'
      },
      {
        src: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/whitepaper/Humble-leadership white paper.pdf'
      },
      {
        src: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/whitepaper/White Paper Corporate Culture.pdf'
      },
      {
        src: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/whitepaper/White Paper Critical Thinking.pdf'
      },
      {
        src: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/whitepaper/White Paper Foundation for Agility.pdf'
      },
      {
        src: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/whitepaper/White Paper Leadership Blind Spot.PDF'
      },
      {
        src: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/whitepaper/White Paper Success in the Era of Artificial Intelligence.pdf'
      },
      {
        src: 'https://ctetyad-public-contents.s3.eu-west-1.amazonaws.com/s/img/ertya/whitepaper/White paper Time to go All In .pdf'
      }
    ]
  },
  News: {
    images: [
      {
        id: 0,
        imageSrc: 'https://media-exp1.licdn.com/dms/image/C4E22AQEcekMaNSSbOg/feedshare-shrink_1280/0/1659333940806?e=1663200000&v=beta&t=d8ydPlEOrC5ur6DDYWwfC0onCdMmIrTCAqwUn7kUMtI',
        alt: '',
        show: false
      },
      {
        id: 1,
        imageSrc: 'https://media-exp1.licdn.com/dms/image/C4E22AQHi7Ung2x8gYQ/feedshare-shrink_1280/0/1656528798746?e=1663200000&v=beta&t=JANq5DPvZgOONILVRYzUzDAGRYYx9BV1n8911iAKs9M',
        alt: '',
        show: false
      },
      {
        id: 2,
        imageSrc: 'https://media-exp1.licdn.com/dms/image/C4E22AQHZx_D7uRb-Ig/feedshare-shrink_1280/0/1655877153089?e=1663200000&v=beta&t=qGeLzsaA2HABIRKT9tI0-ikDohP3Ng3wtlGIeZWb4bc',
        alt: '',
        show: false
      },
      {
        id: 3,
        imageSrc: 'https://media-exp1.licdn.com/dms/image/C4E22AQFNrR5PwOndLA/feedshare-shrink_800/0/1653923219850?e=1663200000&v=beta&t=7dXGjLCvY0zx1npvL4ASPRELm6AnVChdSrPWyOjBVm8',
        alt: '',
        show: false
      },
      {
        id: 4,
        imageSrc: 'https://media-exp1.licdn.com/dms/image/C4E22AQH4B04SXbNZbw/feedshare-shrink_800/0/1653468313148?e=1663200000&v=beta&t=Reh68K3mhRDSZWAJs3qBjagtMTRxkQRk8GALlflv9WA',
        alt: '',
        show: false
      }
    ]
  }
}
